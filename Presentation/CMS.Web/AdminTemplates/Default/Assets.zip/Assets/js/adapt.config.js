﻿// Edit to suit your needs.
var ADAPT_CONFIG={
	// Where is your CSS?
	path: '/assets/admin/styles/960/',

	// false = Only run once, when page first loads.
	// true = Change on window resize and page tilt.
	dynamic: true,

	/*
	callback: function (i,width) {
		var css=$("[isflexgridcss='true']").get(0);
		var path="/assets/admin/styles/";
		if(!css) {
			css=document.createElement('link');
			path&&(document.head||document.getElementsByTagName('head')[0]).appendChild(css);
		}
		css.rel='stylesheet';
		css.media='screen';
		$(css).attr("isflexgridcss","true");
		var arr=ADAPT_CONFIG.range[i].split('=');
		var file=arr[1]?arr[1].replace(/\s/g,''):undefined;
		css.href=path+file.replace(".min.css","_flexgrid.css");
	},
	*/

	range: [
    '980px  to 1280px = 1200.css',
    '1280px to 1600px = 1200.css',
    '1600px to 1920px = 1560.css',
    '1940px to 2540px = 1920.css',
    '2540px           = 2520.css'
  ]
};